package kelas.controller;

import java.io.File;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import kelas.Navigator;
import kelas.data.DataProduk;
import kelas.model.Produk;

public class FormController {

    @FXML
    private TextField namaField, hargaField;
    @FXML
    private ComboBox<String> kategoriBox;
    @FXML
    private Label kodeLabel, pesanLabel;
    @FXML
    private ImageView gambarView;
    private Navigator navigator;
    private DataProduk data;
    private String gambarUri;

    @FXML
    private void initialize() {
        kategoriBox.getItems().addAll("Makanan", "Minuman");
        kategoriBox.setValue("Makanan");
    }

    public void setKonteks(Navigator navigator, DataProduk data) {
        this.navigator = navigator;
        this.data = data;
        perbaruiKode();
    }

    @FXML
    private void perbaruiKode() {
        if (data == null || kategoriBox.getValue() == null) {
            return;
        }
        kodeLabel.setText(data.kodeBerikutnya(kategoriBox.getValue()));
    }

    private void tampilPesan(String teks, boolean berhasil) {
        pesanLabel.getStyleClass().removeAll("error", "success");
        pesanLabel.getStyleClass().add(berhasil ? "success" : "error");
        pesanLabel.setText(teks);
    }

    @FXML
    private void pilihGambar() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Pilih foto produk");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Gambar PNG/JPEG", "*.png", "*.jpg", "*.jpeg"));
        File file = chooser.showOpenDialog(namaField.getScene().getWindow());
        if (file == null) {
            return;
        }
        if (file.length() > 5L * 1024 * 1024) {
            tampilPesan("Maksimum gambar 5 MB.", false);
            return;
        }
        Image image = new Image(file.toURI().toString(), 640, 480, true, true);
        if (image.isError()) {
            tampilPesan("Gambar tidak dapat dibaca.", false);
            return;
        }
        gambarUri = file.toURI().toString();
        gambarView.setImage(image);
        tampilPesan("Foto dipilih.", true);
    }

    @FXML
    private void simpan() {
        try {
            long harga = Long.parseLong(hargaField.getText().trim());
            Produk p = data.tambah(namaField.getText(), kategoriBox.getValue(), harga, gambarUri);
            namaField.clear();
            hargaField.clear();
            kategoriBox.setValue("Makanan");
            gambarUri = null;
            gambarView.setImage(null);
            perbaruiKode();
            tampilPesan("Produk " + p.getKode() + " (" + p.getNama() + ") disimpan dan masuk ke katalog.", true);
        } catch (NumberFormatException e) {
            tampilPesan("Harga harus berupa bilangan bulat, contoh: 15000.", false);
        } catch (IllegalArgumentException e) {
            tampilPesan(e.getMessage(), false);
        }
    }

    @FXML
    private void bukaDaftar() {
        try {
            navigator.bukaDaftar();
        } catch (IOException e) {
            tampilPesan("Gagal membuka daftar.", false);
            e.printStackTrace();
        }
    }

    @FXML
    private void bukaKatalog() {
        try {
            navigator.bukaKatalog();
        } catch (IOException e) {
            tampilPesan("Gagal membuka katalog.", false);
            e.printStackTrace();
        }
    }
}
