package kelas.controller;

import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import kelas.Navigator;
import kelas.data.DataProduk;
import kelas.model.Produk;

public class KatalogController {

    private static final double LEBAR_FOTO = 200;
    private static final double TINGGI_FOTO = 150;

    @FXML
    private TextField cariField;
    @FXML
    private FlowPane kartuPane;
    @FXML
    private Label pesanLabel;

    private Navigator navigator;
    private DataProduk data;

    public void setKonteks(Navigator navigator, DataProduk data) {
        this.navigator = navigator;
        this.data = data;
        tampilkan();
    }

    @FXML
    private void cari() {
        tampilkan();
    }

    @FXML
    private void resetPencarian() {
        cariField.clear();
        tampilkan();
    }

    // Membangun ulang kartu katalog dari data produk yang cocok dengan kata pencarian.
    private void tampilkan() {
        if (data == null) {
            return;
        }
        kartuPane.getChildren().clear();
        String kata = cariField.getText().trim().toLowerCase(Locale.ROOT);
        int jumlah = 0;

        for (Produk produk : data.getDaftar()) {
            String nama = produk.getNama().toLowerCase(Locale.ROOT);
            if (nama.contains(kata)) {
                kartuPane.getChildren().add(buatKartu(produk));
                jumlah++;
            }
        }
        if (jumlah == 0) {
            pesanLabel.setText("Belum ada produk yang sesuai.");
        } else {
            pesanLabel.setText("Jumlah produk di katalog: " + jumlah);
        }
    }

    private VBox buatKartu(Produk produk) {
        // FOTO (atau tulisan "Tanpa foto" jika produk tidak punya foto)
        StackPane fotoBox = new StackPane();
        fotoBox.getStyleClass().add("foto-box");
        fotoBox.setMinSize(LEBAR_FOTO, TINGGI_FOTO);
        fotoBox.setPrefSize(LEBAR_FOTO, TINGGI_FOTO);
        fotoBox.setMaxSize(LEBAR_FOTO, TINGGI_FOTO);

        Image image = null;
        if (produk.getGambarUri() != null) {
            image = new Image(produk.getGambarUri(), LEBAR_FOTO, TINGGI_FOTO, true, true);
            if (image.isError()) {
                image = null;
            }
        }
        if (image != null) {
            ImageView gambarView = new ImageView(image);
            gambarView.setFitWidth(LEBAR_FOTO);
            gambarView.setFitHeight(TINGGI_FOTO);
            gambarView.setPreserveRatio(true);
            fotoBox.getChildren().add(gambarView);
        } else {
            Label tanpaFoto = new Label("Tanpa foto");
            tanpaFoto.getStyleClass().add("muted");
            fotoBox.getChildren().add(tanpaFoto);
        }

        Label kodeLabel = new Label(produk.getKode() + "  •  " + produk.getKategori());
        kodeLabel.getStyleClass().add("muted");

        Label namaLabel = new Label(produk.getNama());
        namaLabel.getStyleClass().add("produk-nama");
        namaLabel.setWrapText(true);

        NumberFormat rupiah = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("id-ID"));
        rupiah.setMaximumFractionDigits(0);
        Label hargaLabel = new Label(rupiah.format(produk.getHarga()));
        hargaLabel.getStyleClass().add("produk-harga");

        Button detailButton = new Button("Lihat Detail");
        detailButton.setMaxWidth(Double.MAX_VALUE);
        detailButton.setOnAction(e -> bukaDetail(produk));

        VBox kartu = new VBox(8, fotoBox, kodeLabel, namaLabel, hargaLabel, detailButton);
        kartu.getStyleClass().add("kartu-produk");
        kartu.setPrefWidth(LEBAR_FOTO + 24);
        kartu.setMaxWidth(LEBAR_FOTO + 24);
        return kartu;
    }

    private void bukaDetail(Produk produk) {
        try {
            navigator.bukaDetail(produk);
        } catch (IOException e) {
            pesanLabel.setText("Detail gagal dibuka.");
            e.printStackTrace();
        }
    }

    @FXML
    private void tambah() {
        try {
            navigator.bukaForm();
        } catch (IOException e) {
            pesanLabel.setText("Form gagal dibuka.");
            e.printStackTrace();
        }
    }

    @FXML
    private void bukaDaftar() {
        try {
            navigator.bukaDaftar();
        } catch (IOException e) {
            pesanLabel.setText("Daftar gagal dibuka.");
            e.printStackTrace();
        }
    }
}
