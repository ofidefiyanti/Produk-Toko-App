package kelas.data;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import kelas.model.Makanan;
import kelas.model.Minuman;
import kelas.model.Produk;

public class DataProduk {

    private final ObservableList<Produk> daftar = FXCollections.observableArrayList();
    private int urutanMakanan = 1;
    private int urutanMinuman = 1;

    public ObservableList<Produk> getDaftar() {
        return FXCollections.unmodifiableObservableList(daftar);
    }
    
    public String kodeBerikutnya(String kategori) {
        if ("Makanan".equals(kategori)) {
            return String.format("MKN%03d", urutanMakanan);
        } else if ("Minuman".equals(kategori)) {
            return String.format("MNM%03d", urutanMinuman);
        }
        throw new IllegalArgumentException("Kategori harus Makanan atau Minuman.");
    }

    public Produk tambah(String nama, String kategori, long harga, String gambarUri) {
        String kode = kodeBerikutnya(kategori);
        Produk p;

        if ("Makanan".equals(kategori)) {
            p = new Makanan(kode, nama, harga, gambarUri);
            urutanMakanan++;
        } else {
            p = new Minuman(kode, nama, harga, gambarUri);
            urutanMinuman++;
        }
        daftar.add(p);
        return p;
    }
}
