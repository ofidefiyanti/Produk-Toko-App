package kelas.model;

public class Makanan extends Produk {

    public Makanan(String kode, String nama, long harga, String gambarUri) {
        super(kode, nama, harga, gambarUri);
    }

    @Override
    public String getKategori() {
        return "Makanan";
    }
}
