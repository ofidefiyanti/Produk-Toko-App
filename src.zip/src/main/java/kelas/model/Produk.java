package kelas.model;

public abstract class Produk {

    private final String kode;
    private final String nama;
    private final long harga;
    private final String gambarUri;

    public Produk(String kode, String nama, long harga, String gambarUri) {
        if (kode == null || kode.isBlank()) {
            throw new IllegalArgumentException("Kode produk tidak boleh kosong.");
        }
        if (nama == null || nama.isBlank()) {
            throw new IllegalArgumentException("Nama produk wajib diisi.");
        }
        if (harga <= 0) {
            throw new IllegalArgumentException("Harga harus lebih dari nol.");
        }
        this.kode = kode;
        this.nama = nama.trim();
        this.harga = harga;
        this.gambarUri = gambarUri;
    }

    public String getKode() {
        return kode;
    }

    public String getNama() {
        return nama;
    }

    public long getHarga() {
        return harga;
    }

    public String getGambarUri() {
        return gambarUri;
    }

    public abstract String getKategori();
}
