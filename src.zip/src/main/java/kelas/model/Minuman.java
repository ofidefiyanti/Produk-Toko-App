package kelas.model;

public class Minuman extends Produk {

    public Minuman(String kode, String nama, long harga, String gambarUri) {
        super(kode, nama, harga, gambarUri);
    }

    @Override
    public String getKategori() {
        return "Minuman";
    }
}
